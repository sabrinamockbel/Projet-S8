#########################################################
#----- 0.a. Differents chargements ----
#########################################################

getwd()



source(file.path("D:/NUS/projet-s8/R functions needed", "emsem_needed_functions.R"))
source(file.path("D:/NUS/projet-s8/R functions needed", "emsem_function.R"))


library(SCGLR)
library(Matrix)
library(expm)
library(graphics)
library(FactoMineR)
library(MASS)
library(abind)
library(mice)
library(VIM)
library(ggplot2)

#Load the dataset
library(readxl)

# Import data from an Excel file (3rd sheet)
pwt <- read_excel("D:/NUS/projet-s8/Data/pwt1001.xlsx", sheet = 3)
pwt_0019 <- pwt[pwt$year >= 2000, ]
pwt_0019_numeric <- pwt_0019[sapply(pwt_0019, is.numeric)]


# List of GDP-related variables
gdp_related_variables <- c('rgdpe', 'rgdpo', 'cgdpe', 'cgdpo', 'rgdpna', 'rconna', 'rdana')
# Create a dataset with only GDP related data to prepare for Y
gdp_data <- pwt_0019_numeric[, gdp_related_variables]

#deal with the NA variables using imputation
imputed_data_1 <- kNN(gdp_data, k = 5)
gdp_data <- imputed_data_1[, !grepl("_imp$", colnames(imputed_data_1))]


# Select non-GDP related variables
variables_to_keep <- c('csh_c', 'csh_i', 'csh_g', 'csh_x', 'csh_m', 'csh_r', 'pl_c', 'pl_i',
                       'pl_g', 'pl_x', 'pl_m', 'pl_n', 'pl_k', 'xr', 'rnna', 'rkna',
                       'rtfpna', 'rwtfpna', 'labsh', 'irr', 'delta')
non_gdp_data <- pwt_0019_numeric[, variables_to_keep]

# Perform k-NN imputation to fill up the NA data
imputed_data_2 <- kNN(non_gdp_data, k = 5)

non_gdp_data <- imputed_data_2[, !grepl("_imp$", colnames(imputed_data_2))]

#Performing a PCA on the dataset
PCA(non_gdp_data, scale.unit = TRUE)


# Create the X1 blocked variable using share in GDP across different economic sectors and other variables in the vertical clusters.
X1 <- non_gdp_data [, c('csh_c','csh_i', 'csh_g', 'csh_r', 'csh_m','csh_x', 'irr')]
# Create X2 with the variables in the horizontal clusters.
X2 <- non_gdp_data [, c( 'pl_c', 'pl_i','pl_g', 'pl_x', 'pl_m', 'pl_n', 'pl_k', 'xr', 'rnna', 'rkna','rtfpna', 'rwtfpna', 'irr', 'delta')]
# Let Y be all GDP related data
Y <- gdp_data

PCA(cbind(X1,X2), scale.unit=TRUE)
# Make them into block-structured data
X1 <- as.matrix(X1)
X2 <- as.matrix(X2)
Y <- as.matrix(Y)


#########################################################
#----- I.b.  Reduction manuelle des matrices de donnees :
#########################################################

X1_r = 0*matrix(1:(nrow(X1)*ncol(X1)), ncol=ncol(X1), nrow = nrow(X1))
X2_r = 0*matrix(1:(nrow(X2)*ncol(X2)), ncol=ncol(X2), nrow = nrow(X2))
Y_r = 0*matrix(1:(nrow(Y)*ncol(Y)), ncol=ncol(Y), nrow = nrow(Y))

for(j in 1:ncol(X1)){
  X1_r[,j] = X1[,j]/sd(X1[,j],na.rm = TRUE)
  
}
for(j in 1:ncol(X2)){
  X2_r[,j] = X2[,j]/sd(X2[,j],na.rm = TRUE)
}

for(j in 1:ncol(Y)){
  Y_r[,j] = Y[,j]/sd(Y[,j],na.rm = TRUE)
}  

X1=X1_r
X2=X2_r
Y=Y_r

#########################################################################
#----- II.  Creation des nb_ech echantillons constitues de n_VC obs
#########################################################################
n_VC = 500
nb_ech = 20
mat_vect = 0 * matrix(1:(n_VC*nb_ech), nrow = n_VC)#chaq col stock les num de lignes pr cr?er les ?chantillons
X1_ech = 0 * array(1:(n_VC*ncol(X1)*nb_ech), dim=c(n_VC,ncol(X1), nb_ech))#chaque tableau stock un echantillon
X2_ech = 0 *array(1:(n_VC*ncol(X2)*nb_ech), dim=c(n_VC,ncol(X2), nb_ech))
Y_ech = 0 *array(1:(n_VC*ncol(Y)*nb_ech), dim=c(n_VC,ncol(Y), nb_ech))

for( j in 1:nb_ech){
  vect = sample(1:nrow(pwt_0019_numeric),n_VC)
  vect = sort(vect)
  mat_vect[,j] = vect
}

for(j in 1:nb_ech){
  lignes = mat_vect[,j]
  X1_ech[,,j] = X1[lignes,]
  X2_ech[,,j] = X2[lignes,]
  Y_ech[,,j] = Y[lignes,]
}

######################
v_unit = matrix(1, ncol=1, nrow = n_VC)
T=v_unit
print(dim(T))
T1=v_unit
T2=v_unit


#########################################################################
#----- III.  Estimation et reconstruction des facteurs par SEM_EM
#########################################################################

A1_est = 0 * array(1:(1*ncol(X1)*nb_ech), dim=c(1,ncol(X1),nb_ech))
A2_est = 0 * array(1:(1*ncol(X2)*nb_ech), dim=c(1,ncol(X2),nb_ech))
B_est = 0 * array(1:(1*ncol(Y)*nb_ech), dim=c(1,ncol(Y),nb_ech))
D_est = 0 * array(1:(ncol(T)*ncol(Y)*nb_ech), dim=c(ncol(T),ncol(Y),nb_ech))
D1_est = 0 * array(1:(ncol(T1)*ncol(X1)*nb_ech), dim=c(ncol(T1),ncol(X1),nb_ech))
D2_est = 0 * array(1:(ncol(T2)*ncol(X2)*nb_ech), dim=c(ncol(T2),ncol(X2),nb_ech))
C_est =  0 * array(1:(1*2*nb_ech), dim=c(1,2,nb_ech))#C1 en col 1 et C2 en col 2.
sigma2_est =  0 * array(1:(1*3*nb_ech), dim=c(1,3,nb_ech))#sigma2_Y_chap en col1; sigma2_X1_chap en col2; sigma2_X2_chap en col3
G_est  = F1_est = F2_est = 0 * array(1:(n_VC*1*nb_ech), dim=c(n_VC,1,nb_ech))
nb_it_cvgce = last_diff = rep(0, nb_ech)

eps_appli = 10^{-3}
nb_it_appli=2
for(est in 1:nb_ech){
  Y = Y_ech[,,est]
  X1 = X1_ech[,,est]
  X2 = X2_ech[,,est]
  n = nrow(Y)
  Estimation = emsem_function(Y,X1,X2,T,T1,T2,epsilon=eps_appli,nb_it=nb_it_appli)
  A1_est[,,est] = Estimation$A1
  A2_est[,,est] = Estimation$A2
  B_est[,,est] = Estimation$B
  D_est[,,est] = Estimation$D 
  D1_est[,,est] = Estimation$D1
  D2_est[,,est] = Estimation$D2
  C_est [,,est] = Estimation$C 
  sigma2_est[,,est] = Estimation$sigma2 
  G_est [,,est] = Estimation$Factors[,1]
  F1_est[,,est] = Estimation$Factors[,2]
  F2_est [,,est] = Estimation$Factors[,3]
  nb_it_cvgce[est]=Estimation$Conv_it
  last_diff[est]=Estimation$Diff
}


#########################################################
#----- IV.Qualite des estimations ----
#########################################################

#######################################################################################
#-----IV.a.Estimations des param pour le data complet : n = nrow(pwt_0019_numeric) 
#######################################################################################

v_unit = matrix(1, ncol=1, nrow = nrow(pwt_0019_numeric))#vecteur unit?
T=v_unit
T_e=matrix(1, ncol=1, nrow = n_VC)
T1=v_unit
T2=v_unit
nb_it_appli = 2
eps_appli = 10^{-3}
Estimation_complet = emsem_function(Y_r,X1_r,X2_r,T,T1,T2,epsilon=eps_appli,nb_it=nb_it_appli)
Estimation_complet$D1

###################################################################################################################################
##-----IV.c. Correlations et MSE entre facteurs concat?n?s (g,f1,f2) de chaque ?ch 
##              avec les facteurs (g,f1,f2) du data complet o? on prend que les indices des individus de l'?chantilllon associ? :
###################################################################################################################################
factors_ech_star = abind(G_est, F1_est, F2_est, along=1)#on empile les facteurs
factors_cor = rep(NA, nb_ech)
factors_star = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))
Ec_factors = 0*matrix(1:(nb_ech*3*n_VC), nrow=nb_ech, ncol=(3*n_VC))
for(j in 1:nb_ech){
  factors_star[,,j] = Estimation_complet$Factors[mat_vect[,j],]
  factors_cor[j] = cor(factors_ech_star[,,j], factors_star[,,j])
  Ec_factors[j,] = (abs(factors_ech_star[,,j] - factors_star[,,j]))^2
}

boxplot(c(factors_cor), col="yellow", main="correlations facteurs entre ech sans cov") 
summary(c(factors_cor))
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.6989  0.8218  0.8777  0.8693  0.9147  0.9648 
MSE_factors_sur_nVC_ech = apply(Ec_factors,2,mean)
boxplot(c(MSE_factors_sur_nVC_ech), col="yellow", 
        main="MSE facteurs entre les complets o? i fixes aux ech et facteurs des ech")
summary(c(MSE_factors_sur_nVC_ech))
#     Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#0.000427  0.017396  0.157050  0.259277  0.263010 12.534714 


#####################################################################################################################################
#-----IV.d. MSE et correlations entre les estimations des param pour n = nrow(genus) et les estimations des param pour n = nb_ech ----
#####################################################################################################################################

theta_star = c(Estimation_complet$A1, Estimation_complet$A2, Estimation_complet$B, Estimation_complet$D, Estimation_complet$D1, 
               Estimation_complet$D2, Estimation_complet$C, Estimation_complet$sigma2)
D_moy_est = 0*array(1:(1*ncol(Y)*nb_ech), dim = c(1, ncol(Y), nb_ech))
for(j in 1:nb_ech){
  D_moy_est[,,j] = D_est[,,j] 
}
#fin
theta_ech_star = abind(A1_est, A2_est, B_est, D_moy_est, D1_est, D2_est, C_est, sigma2_est, along=2)
L_theta = dim(theta_ech_star)[2]
Ec_theta = 0* array(1:(1*L_theta*nb_ech), dim = c(1,L_theta, nb_ech))
Cor_theta = rep(0, nb_ech)

for(est in 1:nb_ech){
  Ec_theta[,,est] = (abs(theta_ech_star[,,est] - theta_star))^2
  Cor_theta[est] = cor(theta_ech_star[,,est], theta_star)
}

MSE_vect = apply(Ec_theta,1:2,sum)/nb_ech
boxplot(c(MSE_vect), col="grey", main="Ecarts rel quad moy (sur 20 ?ch) entre theta* et les theta*ech")
summary(c(MSE_vect))
#Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#0.0000112 0.0019051 0.0086200 0.1134037 0.0971531 0.8362267 
mean(c(MSE_vect))
#0.1134037
boxplot(Cor_theta, col="grey",
        main="Correlations entre theta* et les theta*ech pour les 20 ech")
summary(Cor_theta)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.9642  0.9737  0.9781  0.9783  0.9836  0.9901 


#####################################################################################################################################################
##-----IV.e. Correlations entre Y_chapeau des ?ch et Y_chapeau du data complet o? on prend que les indices des individus de l'?chantilllon associ? :
#####################################################################################################################################################

Y_chap_ech = Y_chap_comp = Y_ec =0*array(1:(n_VC*ncol(Y)*nb_ech), dim=c(n_VC,ncol(Y), nb_ech))

for(j in 1:nb_ech){
  Y_chap_ech[,,j] = T_e%*%t(D_est[,,j]) + G_est[,,j]%*%t(B_est[,,j])
  Y_chap_comp[,,j] =  T_e%*%Estimation_complet$D + Estimation_complet$Factors[c(mat_vect[,j]),1] #%*%Estimation_complet$B
}


for(j in 1:nb_ech){
  Y_ec[,,j] = (abs(Y_chap_comp[,,j] - Y_chap_ech[,,j]))^2
}

Moy_i =apply(Y_ec,2:3,mean)
Moy_i_j =apply(Moy_i,2,mean)
mean(c(Moy_i_j))


##################################################################
##################################################################
# Anciens codes pour mesurer la qualit? des r?sultats :  
##################################################################
##################################################################

#####################################################################################################################################
#-----IV.c. Ecarts quadratiques relatifs moyens entre les facteurs de chaque ?chantillon ----
#####################################################################################################################################

factors_ech_star = abind(G_est, F1_est, F2_est, along=1)

factors_ec = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))
Ec_rel_ech_fact = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))

for(s in 1:nb_ech){
  for(j  in 1:nb_ech){
    if(j==s){j=s+1}
    if(j==(nb_ech+1)){j=nb_ech}
    #cat(j)
    factors_ec[,,j] = (factors_ech_star[,,j] - factors_ech_star[,,s])^2/factors_ech_star[,,s]
  }
  Ec_rel_ech_fact[,,s] = apply(factors_ec, 1:2, sum)/(nb_ech-1)
}

Ec_rel_fact = apply(Ec_rel_ech_fact, 1:2, sum)/nb_ech


sort(Ec_rel_fact)
boxplot(c(Ec_rel_fact), col="yellow", main="Ecarts rel quad moy (sur 20 ech) entre theta* et les theta*ech")
summary(c(Ec_rel_fact))


#######################################################################################################################################################
#-----IV.d.Ecarts quadratiques relatifs moyens entre les estimations des param pour n = nrow(genus) et les estimations des param pour n = nb_ech ----
#######################################################################################################################################################

theta_star = c(Estimation_complet$A1, Estimation_complet$A2, Estimation_complet$B, Estimation_complet$D, Estimation_complet$D1, 
               Estimation_complet$D2, Estimation_complet$C, Estimation_complet$sigma2)
theta_ech_star = abind(A1_est, A2_est, B_est, D_est, D1_est, D2_est, C_est, sigma2_est, along=2)
L_theta = dim(theta_ech_star)[2]
Ec_theta = 0* array(1:(1*L_theta*nb_ech), dim = c(1,L_theta, nb_ech))
for(est in 1:nb_ech){
  Ec_theta[,,est] = ((theta_ech_star[,,est] - theta_star)^2)/theta_star
}

Ec_rel_ech = apply(Ec_theta,1:2,sum)/nb_ech

sort(Ec_rel_ech)
boxplot(c(Ec_rel_ech), col="grey", main="Ecarts rel quad moy (sur 20 ech) entre theta* et les theta*ech")
summary(c(Ec_rel_ech))
#      Min.    1st Qu.     Median       Mean    3rd Qu.       Max. 
#-1.3416797  0.0009416  0.0091736  0.1947231  0.4328532  2.6857227 

###############################
#    Corbeille
################################



tab1 = array(1:(1*2*3), dim=c(1,2,3))
tab2 = array(1:(1*2*3), dim=c(1,2,3))
abind(tab1,tab2, along=2)
apply(tab1, 1:2,sum)

A1_est[,,est] - Estimation_complet$A1
A2_est[,,est] - Estimation_complet$A2
B_est[,,est] - Estimation_complet$B
D_est[,,est] - Estimation_complet$D 
D1_est[,,est] - Estimation_complet$D1
D2_est[,,est] - Estimation_complet$D2
C_est [,,est] - Estimation_complet$C 
sigma2_est[,,est] - Estimation_complet$sigma2 
G_est [,,est] - Estimation_complet$Factors[,1]
F1_est[,,est] - Estimation_complet$Factors[,2]
F2_est [,,est] - Estimation_complet$Factors[,3]



#########################################################
##           Cross-Validadtion to evaluate the accuracy of the model
#########################################################

D_moy <- matrix(0, nrow = 1, ncol = ncol(Y))
B_moy <- matrix(0, nrow = 1, ncol = ncol(Y))
G_moy <- matrix(0, nrow = 500, ncol = 1)

for(i in 1:nb_ech){
  D_moy[,]=D_est[,,i] + D_moy[,]
  B_moy[,]=B_est[,,i] + B_moy[,]
  G_moy[,]=G_est[,,i] + G_moy[,]
}

D_moy[,]=D_moy[,]/nb_ech
B_moy[,]=B_moy[,]/nb_ech
G_moy[,]=G_moy[,]/nb_ech

Y_moy=T_e%*%t(D_moy[,]) + G_moy[,]%*%t(B_moy[,])

Y_dist <- matrix(0, nrow = n_VC, ncol = ncol(Y))
Y_dist_moy <- matrix(0, nrow = n_VC, ncol = ncol(Y))
Y_dist_2<- matrix(0, nrow = n_VC, ncol = 1)

mse_moy<- matrix(0, nrow = 1, ncol = nb_ech)
mse_moy_moy =0
for(j in 1:nb_ech){
  mse_moy[j] = 0
  Y_dist = (abs(Y_chap_comp[,,j] - Y_chap_ech[,,j]))^2
  for(i in 1:n_VC) {
    Y_dist_2[i]=0
    for(l in 1:ncol(Y)){
      Y_dist_2[i]= Y_dist_2[i]+Y_dist[i,l]
    }
  }
  for(k in 1:n_VC){
    mse_moy[j]= Y_dist_2[k]+mse_moy[j]
  }
  mse_moy[j]=mse_moy[j]/n_VC
  print(mse_moy[j])
}

##########################################
for(j in 1:nb_ech){
  Y_dist_moy =(abs(Y_chap_comp[,,j] - Y_moy[,]))^2
}

Y_dist_moy_2<- matrix(0, nrow = n_VC, ncol = 1)
for(i in 1:n_VC) {
  for(l in 1:ncol(Y)){
    Y_dist_moy_2[i]= Y_dist_moy_2[i]+Y_dist[i,l]
  }
}

for(k in 1:n_VC){
  mse_moy_moy =mse_moy_moy+ Y_dist_moy_2[k]
}
mse_moy_moy=mse_moy_moy/n_VC
print(mse_moy_moy)

mse_values <- c(mse_moy/max(mse_moy), mse_moy_moy/max(mse_moy))

# Create a vector for the x-axis labels
x_labels <- c(as.character(1:nb_ech), "Overall")

# Create a data frame with the values and labels
data <- data.frame(MSE = mse_values, Label = factor(x_labels, levels = x_labels))

# Plot the graph
ggplot(data, aes(x = Label, y = MSE)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(x = "Iteration", y = "Mean Squared Error") +
  ggtitle("Mean Squared Error") +
  theme_minimal()

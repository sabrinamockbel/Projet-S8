#-----------------------------------------------------------------------------------------#
#   APPLI data geus du package SCGLR : 3 grpes + (Psi=sigma2*Id)     #
#                         VALIDATION CROISEE                                              #
#                     ---------------------------                                         #
#                                                                                         #
# Program name     : Appli_data_genus.R                                                   #
# Code r��crit par   : Sabrina MOCKBEL                                                         #
# Date de cr�ation : juin 2023                                                           #       
#                                                                                         #
#-----------------------------------------------------------------------------------------#


#########################################################
#----- 0.a. Differents chargements ----
#########################################################


getwd()
#Packages utilis�s (chargement)


#Fonctions (chargement)
source(file.path("C:/Users/mockb/Documents/projet-s8/sabrina", "emsem_needed_functions.R"))
source(file.path("C:/Users/mockb/Documents/projet-s8/sabrina", "emsem_function.R"))



#Chargement des packages
library(SCGLR)
library(Matrix)
library(expm)
library(graphics)
library(FactoMineR)
library(MASS)
library(abind)


#########################################################
#----- 0.b.  Chargement des donn�es genus
#########################################################

data("genus")
dim(genus)


#########################################################
#----- I.  Pr�paration des donn�es
#########################################################

#########################################################
#----- I.a  ACP et selection des faisceaux pour X1 et X2
#########################################################
#X1=genus[,c(28,31:42,67,68)]
#X1=genus[,c(28,29,31:42,67,68)] # avec variable "pluvio_yr" 
X1=genus[,c(28,29,35:40,67,68)] # avec variable "pluvio_yr" et sans pluvio 1,2,3,4,11,12
#sans pluvio 1,2,3,4,11,12 pour bien avoir deux faiseaux un pour X1 et un pour X2
#Pourquoi pas prendre dans un second temps X1=genus[,c(28,29,31:34,67,68)] ?
#Parce que avec X2 qd on fait l'ACP on n'obtient pas deux faisceaux bien nets !
X2=genus[,44:66]

PCA(cbind(X1,X2), scale.unit=TRUE)
#PCA(cbind(X1,X2,genus[,c(31:34,41:42)]), scale.unit=TRUE)#ICI c'est si on veut faire une ACP en dim 3
Y=genus[,1:27]
############
# #Divisons chaque colonne de Y par la colonne surface, �l�ment i par �l�ment i 
 for(j in 1:ncol(Y)){
   Y[,j] = Y[,j]/genus[,ncol(genus)]#rq : ncol(genus) corresp � la derni�re col de genus i.e : "surface"
 }


 X1=as.matrix(X1)
 X2=as.matrix(X2)
 Y=as.matrix(Y)

#########################################################
#----- I.b.  R�duction manuelle des matrices de donn�es :
#########################################################
 
# on cr�e X1_r, X2_r, Y_r de la m�me dimension que X1, X2, Y
X1_r = 0*matrix(1:(nrow(X1)*ncol(X1)), ncol=ncol(X1), nrow = nrow(X1)) 
X2_r = 0*matrix(1:(nrow(X2)*ncol(X2)), ncol=ncol(X2), nrow = nrow(X2))
Y_r = 0*matrix(1:(nrow(Y)*ncol(Y)), ncol=ncol(Y), nrow = nrow(Y))
for(j in 1:ncol(X1)){
  X1_r[,j] = X1[,j]/sd(X1[,j])
  
}
for(j in 1:ncol(X2)){
  X2_r[,j] = X2[,j]/sd(X2[,j])
}
#Divisons chaque colonne de Y par la colonne surface, �l�ment i par �l�ment i 
for(j in 1:ncol(Y)){
  Y[,j] = Y[,j]/genus[,ncol(genus)]#rq : ncol(genus) corresp � la derni�re col de genus i.e : "surface"
}
for(j in 1:ncol(Y)){
  Y_r[,j] = Y[,j]/sd(Y[,j])
}
#J'affecte aux matrices de donn�es les matrices r�duites
X1=X1_r
X2=X2_r
Y=Y_r
#########################################################################
#----- II.  Creation des nb_ech echantillons constitu�s de n_VC obs
#########################################################################
#tirage al�atoire de n_VC observations
n_VC = 500
nb_ech = 20
#creation d'objets de stockage
mat_vect = 0 * matrix(1:(n_VC*nb_ech), nrow = n_VC)#chaq col stock les num de lignes pr cr�er les �chantillons
X1_ech = 0 * array(1:(n_VC*ncol(X1)*nb_ech), dim=c(n_VC,ncol(X1), nb_ech))#chaque tableau stock un echantillon
X2_ech = 0 *array(1:(n_VC*ncol(X2)*nb_ech), dim=c(n_VC,ncol(X2), nb_ech))
Y_ech = 0 *array(1:(n_VC*ncol(Y)*nb_ech), dim=c(n_VC,ncol(Y), nb_ech))
#T_ech = 0 *array(1:(n_VC*2*nb_ech), dim=c(n_VC,2, nb_ech))
#trunc(nrow(genus)*runif(n_VC))



for( j in 1:nb_ech){
  vect = sample(1:nrow(genus),n_VC)
  vect = sort(vect)#ordonne le vecteur (c'est inutile)
  mat_vect[,j] = vect
}

for(j in 1:nb_ech){
  lignes = mat_vect[,j]
  X1_ech[,,j] = X1[lignes,]
  X2_ech[,,j] = X2[lignes,]
  Y_ech[,,j] = Y[lignes,]
  ###########
  #T_ech[,,j] = cbind(v_unit,genus[lignes,43])#A virer si pas de covaiable
}

#SANS Covariables => les vecteurs unit�s qui corresp aux param de moyennes
######################
v_unit = matrix(1, ncol=1, nrow = n_VC)#vecteur unit�
T=v_unit#pas de covariable
print(dim(T))
T1=v_unit
T2=v_unit

#########################################################################
#----- III.  Estimation et reconstruction des facteurs par SEM_EM
#########################################################################

#Objets de stockage des estimations
A1_est = 0 * array(1:(1*ncol(X1)*nb_ech), dim=c(1,ncol(X1),nb_ech))
A2_est = 0 * array(1:(1*ncol(X2)*nb_ech), dim=c(1,ncol(X2),nb_ech))
B_est = 0 * array(1:(1*ncol(Y)*nb_ech), dim=c(1,ncol(Y),nb_ech))
D_est = 0 * array(1:(ncol(T)*ncol(Y)*nb_ech), dim=c(ncol(T),ncol(Y),nb_ech))
D1_est = 0 * array(1:(ncol(T1)*ncol(X1)*nb_ech), dim=c(ncol(T1),ncol(X1),nb_ech))
D2_est = 0 * array(1:(ncol(T2)*ncol(X2)*nb_ech), dim=c(ncol(T2),ncol(X2),nb_ech))
C_est =  0 * array(1:(1*2*nb_ech), dim=c(1,2,nb_ech))#C1 en col 1 et C2 en col 2.
sigma2_est =  0 * array(1:(1*3*nb_ech), dim=c(1,3,nb_ech))#sigma2_Y_chap en col1; sigma2_X1_chap en col2; sigma2_X2_chap en col3
G_est  = F1_est = F2_est = 0 * array(1:(n_VC*1*nb_ech), dim=c(n_VC,1,nb_ech))
nb_it_cvgce = last_diff = rep(0, nb_ech)
 


eps_appli = 10^{-3}
nb_it_appli=100
#Lancement de l'algo EM par sa fonction
for(est in 1:nb_ech){
Y = Y_ech[,,est]
X1 = X1_ech[,,est]
X2 = X2_ech[,,est]

n = nrow(Y)#ligne de bricollage

Estimation = emsem_function(Y,X1,X2,T,T1,T2,epsilon=eps_appli,nb_it=nb_it_appli)

#Stockage des estimations
A1_est[,,est] = Estimation$A1
A2_est[,,est] = Estimation$A2
B_est[,,est] = Estimation$B
D_est[,,est] = Estimation$D #verif que la class de Estimation$D est une matrice, sinn le stockage peut �tre affect� => OK!
D1_est[,,est] = Estimation$D1
D2_est[,,est] = Estimation$D2
C_est [,,est] = Estimation$C #C1 en col 1 et C2 en col 2.
sigma2_est[,,est] = Estimation$sigma2 #sigma2_Y_chap en col1; sigma2_X1_chap en col2; sigma2_X2_chap en col3
G_est [,,est] = Estimation$Factors[,1]
F1_est[,,est] = Estimation$Factors[,2]
F2_est [,,est] = Estimation$Factors[,3]
nb_it_cvgce[est]=Estimation$Conv_it
last_diff[est]=Estimation$Diff
}



#D'o� les rbind() dans la boucle for qui suit


for(j in 1:nb_ech){
  #500 lignes (n_VC) et 27 colonnes
  Y_chap_ech[,,j] = T_e%*%t(D_est[,,j]) + G_est[,,j]%*%t(B_est[,,j])
  Y_chap_comp[,,j] =  T_e%*%Estimation_complet$D + Estimation_complet$Factors[c(mat_vect[,j]),1] #%*%Estimation_complet$B
}



##########################

#########################################################
#----- IV.Qualit� des estimations ----
#########################################################

#######################################################################################
#-----IV.a.Estimations des param pour le data complet : n = nrow(genus) 
#######################################################################################
X1=genus[,c(28,29,35:40,67,68)] # avec variable "pluvio_yr" et sans pluvio 1,2,3,4,11,12
X2=genus[,44:66]
Y=genus[,1:27]
#r�duction manuelle des matrices de donn�es compl�tes
X1_r = 0*matrix(1:(nrow(X1)*ncol(X1)), ncol=ncol(X1), nrow = nrow(X1))
X2_r = 0*matrix(1:(nrow(X2)*ncol(X2)), ncol=ncol(X2), nrow = nrow(X2))
Y_r = 0*matrix(1:(nrow(Y)*ncol(Y)), ncol=ncol(Y), nrow = nrow(Y))
#r�duisons X1
for(j in 1:ncol(X1)){
  X1_r[,j] = X1[,j]/sd(X1[,j])
}
#r�duisons X2
for(j in 1:ncol(X2)){
X2_r[,j] = X2[,j]/sd(X2[,j])
}
#Divisons chaque colonne de Y par la colonne surface, �l�ment i par �l�ment i
for(j in 1:ncol(Y)){
  Y[,j] = Y[,j]/genus[,ncol(genus)]#rq : ncol(genus) corresp � la derni�re col de genus i.e : "surface"
}

#r�duisons Y
for(j in 1:ncol(Y)){
  Y_r[,j] = Y[,j]/sd(Y[,j])
}
n=nrow(Y_r)
#+Pas de Covariables => les covariables sont des vecteurs unit�s qui corresp aux param de moyennes

v_unit = matrix(1, ncol=1, nrow = nrow(genus))#vecteur unit�


#T=cbind(v_unit,genus[,43])
T=v_unit

T_e=matrix(1, ncol=1, nrow = n_VC)


T1=v_unit
T2=v_unit
nb_it_appli = 100
eps_appli = 10^{-3}
Estimation_complet = emsem_function(Y_r,X1_r,X2_r,T,T1,T2,epsilon=eps_appli,nb_it=nb_it_appli)


Estimation_complet$D1


# ################################################
# #-----IV.b.ACP des diff�rents �chantillons  ----
# ################################################
# for(ech in 1:nb_ech){
#   PCA(cbind(X1_ech[,,ech],X2_ech[,,ech]), scale.unit=TRUE)
# }

###################################################################################################################################
##-----IV.c. Correlations et MSE entre facteurs concat�n�s (g,f1,f2) de chaque �ch 
##              avec les facteurs (g,f1,f2) du data complet o� on prend que les indices des individus de l'�chantilllon associ� :
###################################################################################################################################
factors_ech_star = abind(G_est, F1_est, F2_est, along=1)#on empile les facteurs
factors_cor = rep(NA, nb_ech)
factors_star = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))
Ec_factors = 0*matrix(1:(nb_ech*3*n_VC), nrow=nb_ech, ncol=(3*n_VC))
for(j in 1:nb_ech){
  factors_star[,,j] = Estimation_complet$Factors[mat_vect[,j],]
  factors_cor[j] = cor(factors_ech_star[,,j], factors_star[,,j])
  Ec_factors[j,] = (abs(factors_ech_star[,,j] - factors_star[,,j]))^2
}
#Correlations
boxplot(c(factors_cor), col="yellow", main="correlations facteurs entre ech sans cov") #Mauvais resultats !
summary(c(factors_cor))
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.9879  0.9927  0.9949  0.9945  0.9968  0.9988 
#MSE
MSE_factors_sur_nVC_ech = apply(Ec_factors,2,mean)
boxplot(c(MSE_factors_sur_nVC_ech), col="yellow", 
        main="MSE facteurs entre les complets o� i fix�s aux ech et facteurs des �ch") #Mauvais resultats !
summary(c(MSE_factors_sur_nVC_ech))
#     Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 0.0006597 0.0019040 0.0029040 0.0102100 0.0143700 0.2224000 
#####################################################################################################################################
#-----IV.d. MSE et correlations entre les estimations des param pour n = nrow(genus) et les estimations des param pour n = nb_ech ----
#####################################################################################################################################

theta_star = c(Estimation_complet$A1, Estimation_complet$A2, Estimation_complet$B, Estimation_complet$D, Estimation_complet$D1, 
               Estimation_complet$D2, Estimation_complet$C, Estimation_complet$sigma2)
#Pour construire theta_ech_star besoin de s�parer D_est en deux : pour param moy et param pond�rateur de la covariable:
#debut
D_moy_est = 0*array(1:(1*ncol(Y)*nb_ech), dim = c(1, ncol(Y), nb_ech))
for(j in 1:nb_ech){
  D_moy_est[,,j] = D_est[,,j] 
}
#fin
theta_ech_star = abind(A1_est, A2_est, B_est, D_moy_est, D1_est, D2_est, C_est, sigma2_est, along=2)
print(dim(theta_ech_star))
L_theta = dim(theta_ech_star)[2]#2*ncol(X1)+2*ncol(X2)+2*ncol(Y)+2+3

Ec_theta = 0* array(1:(1*L_theta*nb_ech), dim = c(1,L_theta, nb_ech))
Cor_theta = rep(0, nb_ech)
# MSE = E[|theta_chap - theta|^2] ; l'esp�rance est sur la longueur de theta
for(est in 1:nb_ech){
  Ec_theta[,,est] = (abs(theta_ech_star[,,est] - theta_star))^2
  #Poposition d'un pseudo MSE relatif ds le cas o� on ne normalise pas les variables des blocs Y, X1, X2 du data
  #Ec_theta[,,est] = ((abs(theta_ech_star[,,est] - theta_star))^2)/theta_star
  Cor_theta[est] = cor(theta_ech_star[,,est], theta_star)
}
###
MSE_vect = apply(Ec_theta,1:2,sum)/nb_ech#moyenne sur le nb d'�ch

#MSE
boxplot(c(MSE_vect), col="grey", main="Ecarts rel quad moy (sur 20 �ch) entre theta* et les theta*ech")
summary(c(MSE_vect))
#     Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 0.0002251 0.0009391 0.0011970 0.0021270 0.0019850 0.0132100 
mean(c(MSE_vect))
#0.002126906
#Correlations
boxplot(Cor_theta, col="grey",
        main="Correlations entre theta* et les theta*ech pour les 20 ech")
summary(Cor_theta)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1       1       1       1       1       1   



#####################################################################################################################################################
##-----IV.e. Correlations entre Y_chapeau des �ch et Y_chapeau du data complet o� on prend que les indices des individus de l'�chantilllon associ� :
#####################################################################################################################################################

Y_chap_ech = Y_chap_comp = Y_ec =0*array(1:(n_VC*ncol(Y)*nb_ech), dim=c(n_VC,ncol(Y), nb_ech))
#on va empiler sur une colonne les variables de Y => NON


Y_moy=T_moy%*%t(D_moy[,]) + G_moy[,]%*%t(B_moy[,])

#D'o� les rbind() dans la boucle for qui suit

for(j in 1:nb_ech){
  #500 lignes (n_VC) et 27 colonnes
  Y_chap_ech[,,j] = T_e%*%t(D_est[,,j]) + G_est[,,j]%*%t(B_est[,,j])
  Y_chap_comp[,,j] =  T_e%*%Estimation_complet$D + Estimation_complet$Factors[c(mat_vect[,j]),1] #%*%Estimation_complet$B
}


# Calcul des param�tres theta moyen
D_moy <- matrix(0, nrow = 1, ncol = ncol(Y))
B_moy <- matrix(0, nrow = 1, ncol = ncol(Y))
G_moy <- matrix(0, nrow = 500, ncol = 1)

for(i in 1:nb_ech){
  D_moy[,]=D_est[,,i] + D_moy[,]
  B_moy[,]=B_est[,,i] + B_moy[,]
  G_moy[,]=G_est[,,i] + G_moy[,]
}

D_moy[,]=D_moy[,]/nb_ech
B_moy[,]=B_moy[,]/nb_ech
G_moy[,]=G_moy[,]/nb_ech
#calcul du Y estim� par theta moyen
Y_moy=T_e%*%t(D_moy[,]) + G_moy[,]%*%t(B_moy[,])


#MSE entre le Y estim� par le mod�le moyen et pour les �chantillons, et le Y estim� avec le data complet 

Y_dist <- matrix(0, nrow = n_VC, ncol = ncol(Y))
Y_dist_moy <- matrix(0, nrow = n_VC, ncol = ncol(Y))
Y_dist_2<- matrix(0, nrow = n_VC, ncol = 1)

mse_moy<- matrix(0, nrow = 1, ncol = nb_ech)
mse_moy_moy =0
for(j in 1:nb_ech){
  mse_moy[j] = 0
  Y_dist = (abs(Y_chap_comp[,,j] - Y_chap_ech[,,j]))^2
  for(i in 1:n_VC) {
    Y_dist_2[i]=0 
    for(l in 1:ncol(Y)){
      Y_dist_2[i]= Y_dist_2[i]+Y_dist[i,l]
    }
  }
  for(k in 1:n_VC){
    mse_moy[j]= Y_dist_2[k]+mse_moy[j]
  }
  mse_moy[j]=mse_moy[j]/n_VC
  print(mse_moy[j])
}

##########################################
for(j in 1:nb_ech){
  Y_dist_moy =(abs(Y_chap_comp[,,j] - Y_moy[,]))^2
}


Y_dist_moy_2<- matrix(0, nrow = n_VC, ncol = 1)
for(i in 1:n_VC) {
  for(l in 1:ncol(Y)){
    Y_dist_moy_2[i]= Y_dist_moy_2[i]+Y_dist[i,l]
  }
}

for(k in 1:n_VC){
  mse_moy_moy =mse_moy_moy+ Y_dist_moy_2[k]
}
mse_moy_moy=mse_moy_moy/n_VC
print(mse_moy_moy)


#moy sur les i
Moy_i =apply(Y_ec,2:3,mean)#chaque colonne correspond � la moyenne sur les n_VC i de chacune des j in 1 to q_Y=27 variables
print(dim(Moy_i))
# matrice de 0
Moy_i_j =apply(Moy_i,2,mean)#20 moy sur i puis j i.e : une moy pour chacun des n_VC �chantillons
print(Moy_i_j)
# vecteur de 0
mean(c(Moy_i_j))#ca ne correspond pas � sig2_Y peut �tre qu'isoler les observations n'a pas de sens.









##################################################################
##################################################################
# Anciens codes pour mesurer la qualit� des r�sultats :  
##################################################################
##################################################################

#####################################################################################################################################
#-----IV.c. Ecarts quadratiques relatifs moyens entre les facteurs de chaque �chantillon ----
#####################################################################################################################################

factors_ech_star = abind(G_est, F1_est, F2_est, along=1)#on empile les facteurs

factors_ec = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))
Ec_rel_ech_fact = 0* array(1:(3*n_VC*1*nb_ech), dim = c(3*n_VC, 1, nb_ech))

for(s in 1:nb_ech){
  for(j  in 1:nb_ech){
    if(j==s){j=s+1}
    if(j==(nb_ech+1)){j=nb_ech}
    #cat(j)
    factors_ec[,,j] = (factors_ech_star[,,j] - factors_ech_star[,,s])^2/factors_ech_star[,,s]
  }
  Ec_rel_ech_fact[,,s] = apply(factors_ec, 1:2, sum)/(nb_ech-1)
}

Ec_rel_fact = apply(Ec_rel_ech_fact, 1:2, sum)/nb_ech


sort(Ec_rel_fact)
boxplot(c(Ec_rel_fact), col="yellow", main="Ecarts rel quad moy (sur 20 �ch) entre theta* et les theta*ech")
summary(c(Ec_rel_fact))
#    Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#-383.8000   -1.3150   -0.3529   -0.4457    0.8706   95.5600 

#dim(factors_ech_star)

#######################################################################################################################################################
#-----IV.d.Ecarts quadratiques relatifs moyens entre les estimations des param pour n = nrow(genus) et les estimations des param pour n = nb_ech ----
#######################################################################################################################################################

theta_star = c(Estimation_complet$A1, Estimation_complet$A2, Estimation_complet$B, Estimation_complet$D, Estimation_complet$D1, 
               Estimation_complet$D2, Estimation_complet$C, Estimation_complet$sigma2)
theta_ech_star = abind(A1_est, A2_est, B_est, D_est, D1_est, D2_est, C_est, sigma2_est, along=2)
L_theta = dim(theta_ech_star)[2]#2*ncol(X1)+2*ncol(X2)+2*ncol(Y)+2+3
Ec_theta = 0* array(1:(1*L_theta*nb_ech), dim = c(1,L_theta, nb_ech))
for(est in 1:nb_ech){
  Ec_theta[,,est] = ((theta_ech_star[,,est] - theta_star)^2)/theta_star
}

Ec_rel_ech = apply(Ec_theta,1:2,sum)/nb_ech

sort(Ec_rel_ech)
boxplot(c(Ec_rel_ech), col="grey", main="Ecarts rel quad moy (sur 20 �ch) entre theta* et les theta*ech")
summary(c(Ec_rel_ech))
# Min.    1st Qu.     Median       Mean    3rd Qu.       Max. 
# -0.9001000  0.0000142  0.0004102  0.0239600  0.0068850  1.1120000 









###############################
#    Corbeille
################################



tab1 = array(1:(1*2*3), dim=c(1,2,3))
tab2 = array(1:(1*2*3), dim=c(1,2,3))
abind(tab1,tab2, along=2)
apply(tab1, 1:2,sum)
#?abind

A1_est[,,est] - Estimation_complet$A1
A2_est[,,est] - Estimation_complet$A2
B_est[,,est] - Estimation_complet$B
D_est[,,est] - Estimation_complet$D #verif que la class de Estimation$D est une matrice, sinn le stockage peut �tre affect� => OK!
D1_est[,,est] - Estimation_complet$D1
D2_est[,,est] - Estimation_complet$D2
C_est [,,est] - Estimation_complet$C #C1 en col 1 et C2 en col 2.
sigma2_est[,,est] - Estimation_complet$sigma2 #sigma2_Y_chap en col1; sigma2_X1_chap en col2; sigma2_X2_chap en col3
G_est [,,est] - Estimation_complet$Factors[,1]
F1_est[,,est] - Estimation_complet$Factors[,2]
F2_est [,,est] - Estimation_complet$Factors[,3]

#calcul de Ymax sur les colonnes et les lignes
max_val = 0
for (i in 1:nrow(Y)) {
  for (j in 1:ncol(Y)) {
    if (max_val <= Y[i, j]) {
      max_val = Y[i, j]
    }
  }
}
print(max_val)



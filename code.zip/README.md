# S8 Apprentissage de modèles prédictifs à partir de données structurées en blocs



# Project details

Le code est composé de deux fichiers:

Celuis ACP python, 

Ou le note book illsutre comment se servir de la fonction ACP

Celui code R, 

ou ensem_function et ensemn_needed_function sont les codes des fonctions permettant l'applicationde l'algorithme EM.
Les deux autres fichier correspondent au travail d'analyse effectué sur les deux jeux de données

# Link to this Project

https://gitlab-student.centralesupelec.fr/minjia.fu/s8-apprentissage-de-modeles-predictifs-a-partir-de-donnees-structurees-en-blocs.git

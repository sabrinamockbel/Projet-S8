# ' An simultaneous EM estimation of a structural equation model and its latent factors.
# '
# ' This function allows you to fit a structural equation model with one bloc of dependant observed variables
# ' and two blocs of explanatory observed variables.
# ' Underlying to each bloc there is a latent factor which is simultaneously reconstructed.
# ' @param Y numeric output matrix (or vector) which is the dependant bloc of observed variables.
# ' @param X1 numeric input matrix (or vector) which is one explanatory bloc of observed variables.
# ' @param X2 numeric input matrix (or vector) which is one explanatory bloc of observed variables.
# ' @param T numeric input matrix (or vector) for extra-covariates linked to Y.
# ' @param T1 numeric input matrix (or vector) for extra-covariates linked to X1.
# ' @param T2 numeric input matrix (or vector) for extra-covariates linked to X2.
# ' @param epsilon numeric accuracy for the convergence criterion.
# ' @param nb_it numeric for give a maximal number of iteration.
# ' @return list giving the reconstructed latent factor values,
# '  the estimated model’s coefficients, the value of the stopping criterion,
# '  the number of iterations effected.
# ' @keywords latent factors
# ' @author Myriam Tami, \email{myriam.tami@@univ-grenoble-alpes.fr}
# ' @references \url{https://myriamtami.github.io/data/publications/Tami_thesis.pdf}
# ' @export
# ' @examples
# ' emsem_function()

# C'est quoi export?
# je met des mots clés?
# Comment sourcer les fonctions de l'autre .R devant ma fonction?
# Est ce que je met un exemple de datas simulées ?

import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm


def emsem_function(Y, X1, X2, T, T1, T2, epsilon=10**(-3), nb_it=100):

  # Function arguments
  # X1      : (matrix) block of data concerning the first factor
  # X2      : (matrix) block of data concerning the second factor
  # Y       : (matrix/vecteur) response variable
  # epsilon : (real) criterion of convergence
  # nb_it   : (integer) number of iteration
  # nb_it = 100  # limite du nombre d'itirations

  ##################################
  # ----ENTRE DE PARAMETRES----
  ##################################
  qX1 = X1.shape[1]
  qX2 = X2.shape[1]
  qY = Y.shape[1]
  qT = T.shape[1]  # New
  qT1 = T1.shape[1]  # New
  qT2 = T2.shape[1]  # New
  kF1 = 1  # CHOIX SELON NOTRE REDACTION : SI != 1 LES RESULTATS NE SONT PAS GARANTIS!
  kF2 = 1
  kG = 1  # CHOIX SELON NOTRE REDACTION : SI != 1 LES RESULTATS NE SONT PAS GARANTIS!
  n = Y.shape[0]
  nb_fact = kF1+kF2+kG

  ######################################################
  # ----PARAMETRES A ESTIMER : CREATION OBJETS----
  ######################################################

  A1 = np.zeros((kF1, qX1))
  A2 = np.zeros((kF2, qX2))
  B = np.zeros((kG, qY))
  C1 = 0
  C2 = 0
  # New
  D = np.zeros((qT, qY))
  D1 = np.zeros((qT1, qY))
  D2 = np.zeros((qT2, qY))
  Psi_X1 = np.zeros((qX1, qX1))
  Psi_X2 = np.zeros((qX2, qX2))
  Psi_Y = np.zeros((qY, qY))
  sigma2_X1_chap = 0
  sigma2_X2_chap = 0
  sigma2_Y_chap = 0

  # Objets necessaires a l'estimation des sigma2 chapeau
  # Pour X1
  dud1_X1 = np.zeros((n, qX1))
  res1_X1 = np.zeros((n, 1))
  res2_X1 = np.zeros((n, 1))
  res3_X1 = np.zeros((n, 1))
  res_X1_chap = np.zeros((n, 1))
  # sigma2_X1_chap : objet de taille 1*1 => non construit
  # Pour X2
  dud1_X2 = np.zeros((n, qX2))
  res1_X2 = np.zeros((n, 1))
  res2_X2 = np.zeros((n, 1))
  res3_X2 = np.zeros((n, 1))
  res_X2_chap = np.zeros((n, 1))
  # sigma2_X_chap : objet de taille 1*1 => non construit

#


# Pour Y
dud1_Y = np.zeros((n, qY))
res1_Y = np.zeros((n, 1))
res2_Y = np.zeros((n, 1))
res3_Y = np.zeros((n, 1))
res_Y_chap = np.zeros((n, 1))
# sigma2_Y_chap : objet de taille 1*1 => non construit

# Objets necessaires pour le stock des valeurs des parametres a l'iteration precedente :
# Objectif : calculer la difference entre chaque it nommee diff pour le critere d'arret
A1_it = np.zeros((kF1, qX1))
A2_it = np.zeros((kF2, qX2))
B_it = np.zeros((kG, qY))
C1_it = 0
C2_it = 0
# New
D_it = np.zeros((qT, qY))
D1_it = np.zeros((qT1, qY))
D2_it = np.zeros((qT2, qY))
sigma2_X1_chap_it = 0
sigma2_X2_chap_it = 0
sigma2_Y_chap_it = 0


#
#####################################################################################################
  #
  # -----INITIALISATION PAR ACP ET REGRESSION-----
  #
  #####################################################################################################

# Pour l'équation de X1
# Régression pour estimation de D1_sim
regX1_Fact = LinearRegression(fit_intercept=False).fit(T1, X1)
ini_D1 = regX1_Fact.coef_[:qT1]  # Nouveau

# Régression pour estimation de A1_sim et sigma2X1
pcaX1_Fact = PCA(n_components=1, svd_solver='full').fit_transform(
    X1 - np.dot(T1, ini_D1))
regX1_Fact = LinearRegression(fit_intercept=False).fit(
    pcaX1_Fact, X1 - np.dot(T1, ini_D1))
ini_A1_Fact = np.matrix(regX1_Fact.coef_).reshape(1, qX1)
sig_lm_qX1_Fact = np.empty(qX1)
for i in range(qX1):
    sig_lm_qX1_Fact[i] = regX1_Fact._residues / \
        (regX1_Fact.nobs - regX1_Fact.rank)
# Initialisation du paramètre sigma2X1
ini_sigma2X1_Fact = np.mean(sig_lm_qX1_Fact)

# Pour l'équation de X2
# Régression pour estimation de D2_sim
regX2_Fact = LinearRegression(fit_intercept=False).fit(T2, X2)
ini_D2 = regX2_Fact.coef_[:qT2]  # Nouveau

# Régression pour estimation de A2_sim et sigma2X2
pcaX2_Fact = PCA(n_components=1, svd_solver='full').fit_transform(
    X2 - np.dot(T2, ini_D2))
regX2_Fact = LinearRegression(fit_intercept=False).fit(
    pcaX2_Fact, X2 - np.dot(T2, ini_D2))
ini_A2_Fact = np.matrix(regX2_Fact.coef_).reshape(1, qX2)
sig_lm_qX2_Fact = np.empty(qX2)
for i in range(qX2):
    sig_lm_qX2_Fact[i] = regX2_Fact._residues / \
        (regX2_Fact.nobs - regX2_Fact.rank)
# Initialisation du paramètre sigma2X2
ini_sigma2X2_Fact = np.mean(sig_lm_qX2_Fact)

#

# Regression pour estimation de D_sim
regY_Fact = sm.OLS(Y, T).fit()
ini_D = regY_Fact.params[0:qT]  # New

# Regression pour estimation de B_sim et sigma2Y
# donne la premiere composante d'apres FactomineR : correspond au facteur G
cl1Y_Fact = PCA(Y - T.dot(ini_D), scale.unit=False).ind.coord[:, 0]
# premiere composante de G a normer par le residu de la regression pour gagner du temps
cl1Y_Fact = cl1Y_Fact / \
    (sm.OLS(cl1Y_Fact, sm.add_constant([cl1X1_Fact, cl1X2_Fact])).fit().scale)
regY_Fact = sm.OLS(Y - T.dot(ini_D), cl1Y_Fact).fit()
ini_B_Fact = np.matrix(regY_Fact.params).reshape(1, qY)
sig_lm_qY_Fact = np.repeat(np.nan, qY)
for i in range(qY):
    sig_lm_qY_Fact[i] = regY_Fact.bse[i]
# initialisation du parametre sigma2Y
ini_sigma2Y_Fact = np.mean(sig_lm_qY_Fact**2)

# Regression de l'initialisation de F sur celle de G pour estimation C_sim
regG_Fact = sm.OLS(cl1Y_Fact, sm.add_constant([cl1X1_Fact, cl1X2_Fact])).fit()
ini_C1_Fact = regG_Fact.params[0]  # initialisation du parametre C1
ini_C2_Fact = regG_Fact.params[1]  # initialisation du parametre C2


#

############################################
# Début initialisation
############################################
A1 = ini_A1_Fact
A2 = ini_A2_Fact
B = ini_B_Fact
C1 = ini_C1_Fact
C2 = ini_C2_Fact
D = ini_D  # Nouveau
D1 = ini_D1  # Nouveau
D2 = ini_D2  # Nouveau
sigma2_X1_chap = ini_sigma2X1_Fact
sigma2_X2_chap = ini_sigma2X2_Fact
sigma2_Y_chap = ini_sigma2Y_Fact
# D'où ?
# Nécessaire pour boucler le calcul de M-i et Sigma_i de la loi qui donne F_tilde, G_tilde, Phi_tilde et Gamma_tilde
Psi_X1 = np.diag(sigma2_X1_chap, qX1)
Psi_X2 = np.diag(sigma2_X2_chap, qX2)
Psi_Y = np.diag(sigma2_Y_chap, qY)
########################
#
# FIN INITIALISATION
#
########################

it = 0 # ATTENTION it = 0 cree des objets de taille nulle et des bugs ds while{} a partir ligne 118 si it ne passe pas a it=0+1

#On cree un vecteur qui va contenir les differences d'une iteration a l'autre pour voir l'evolution de la convergence
diffgraph =  np.zeros((nb_it-1, 1))

diff = 1 # valeur initiale du parametre mesurant le changemet de valeur de theta^[t] d'une iteration a l'autre
#D'ou, l'initialisation se traduit au niveau de diffgraph par : 
diffgraph[0] = 1

detE2 =  np.zeros((nb_it, 1))



#

while (diff > epsilon) and ((it := it+1) < nb_it):
    # Calculate phi_tilde, gamma_tilde, f_tilde, and g_tilde for the n individuals i:
    # First need to define M_i and GAMMA_i resp. The mean vector and var-cov matrix of the normal distribution of H_i|Z_i

    # Define elements necessary for defining the parameters at iteration [t+1]:
    # c1 and c2 are real in the case of a factor, '*', and not '%*%'
    E1_1 = np.c_[((C1)**2 + (C2)**2 + 1)*B, C1*A1, C2*A2]
    E1_2 = np.c_[C1*B, A1, np.zeros(qX2)]
    E1_3 = np.c_[C2*B, np.zeros(qX1), A2]
    E1 = np.r_[E1_1, E1_2, E1_3]

    # c1 and c2 are real in the case of a factor, '*', and not '%*%'
    E2_1 = np.c_[(C1**2 + C2**2 + 1)*B.T @ B + Psi_Y, C1*B.T @ A1, C2*B.T @ A2]
    E2_2 = np.c_[C1*A1.T @ B, A1.T @ A1 + Psi_X1, np.zeros((qX1, qX2))]
    E2_3 = np.c_[C2*A2.T @ B, np.zeros((qX1, qX2)), A2.T @ A2 + Psi_X2]
    E2 = np.r_[E2_1, E2_2, E2_3]

    detE2[it, :] = np.linalg.det(E2)

    E3 = np.zeros((qY+qX1+qX2, 1, n))
    for i in range(n):
        E3[:, :, i] = np.c_[Y[i, :] - D.T @ T[i, :], X1[i, :] -
            D1.T @ T1[i, :], X2[i, :] - D2.T @ T2[i, :]]

    # M_i corresponds to E1 @ np.linalg.solve(E2, E3[:, :, i])
    # Code GAMMA_i
    E4 = np.array([[C1**2 + C2**2 + 1, C1, C2, C1, 1, 0, C2, 0, 1]])
    E4 = np.tile(E4, (n, 1))
    GAMMA = E4 - E1 @ np.linalg.pinv(E2) @ E1.T

    EE = E1 @ np.linalg.pinv(E2)
    tEE = E1.T @ np.linalg.pinv(E2).T
    fg = prod_tab_mat(EE, E3)  # fg is a table of i=1 to n elements fg[:, :, i]
    # each fg[:, :, i] contains, the first kG lines m_{1i} that is the first mean element of h_i|z_i
    # and the following kF1 lines contains m_{2i} and the last kF2 lines contains m_{3i}

    #

    # G_tilde
    G_tilde = fg[0:kG, :, :].reshape(kG, fg.shape[1], fg.shape[2])
    # G_tilde_bar
    G_tilde_bar = G_tilde.mean(axis=(1, 2))

    # F1_tilde
    F1_tilde = fg[kG:kG+kF1, :, :].reshape(kF1, fg.shape[1], fg.shape[2])
    # F1_tilde_bar
    F1_tilde_bar = F1_tilde.mean(axis=(1, 2))

    # F2_tilde
    F2_tilde = fg[kG+kF1:kG+kF1+kF2, :,
        :].reshape(kF2, fg.shape[1], fg.shape[2])
    # F2_tilde_bar
    F2_tilde_bar = F2_tilde.mean(axis=(1, 2))

    # G_tilde_Y_bar
    G_tilde_Y_bar = moy_TildeData(G_tilde, Y).T

    # G_tilde_T_prim_bar
    G_tilde_T_prim_bar = moy_TildeData(G_tilde, T)
    # Rq: on ne met pas t(T) car code ds la fction moy_TildeData()

    # G_tilde_T_bar
    G_tilde_T_bar = moy_TildeData(G_tilde, T).T

    # F1_tilde_X1_bar
    F1_tilde_X1_bar = moy_TildeData(F1_tilde, X1).T

    # F2_tilde_X2_bar
    F2_tilde_X2_bar = moy_TildeData(F2_tilde, X2).T

    # F1_tilde_T1_prim_bar
    F1_tilde_T1_prim_bar = moy_TildeData(F1_tilde, T1)

    # F2_tilde_T2_prim_bar
    F2_tilde_T2_prim_bar = moy_TildeData(F2_tilde, T2)

    # F1_tilde_T1_bar
    F1_tilde_T1_bar = moy_TildeData(F1_tilde, T1).T

    # F2_tilde_T2_bar
    F2_tilde_T2_bar = moy_TildeData(F2_tilde, T2).T

    # Y_T_prim_bar
    Y_T_prim_bar = moy_T_Prim_Data(Y, T)

    # X1_T1_prim_bar
    X1_T1_prim_bar = moy_T_Prim_Data(X1, T1)

    # X2_T2_prim_bar
    X2_T2_prim_bar = moy_T_Prim_Data(X2, T2)

    # objet cree pour creer l'objet G_tilde_bar_2 qui va suivre
    moy_G_tilde = G_tilde.mean(axis=(1, 2))

    # objet cree pour creer l'objet F1_tilde_bar_2 qui va suivre
    moy_F1_tilde = F1_tilde.mean(axis=(1, 2))

    # objet cree pour creer l'objet F2_tilde_bar_2 qui va suivre
    moy_F2_tilde = F2_tilde.mean(axis=(1, 2))

    # G_tilde_bar_2
    G_tilde_bar_2 = np.outer(moy_G_tilde, moy_G_tilde)

    # F1_tilde_bar_2
    F1_tilde_bar_2 = np.outer(moy_F1_tilde, moy_F1_tilde)

    # F2_tilde_bar_2
    F2_tilde_bar_2 = np.outer(moy_F2_tilde, moy_F2_tilde)

    #

    # F1G_tilde_bar
    F1G_tilde_bar = moy_fg_tilde(F1_tilde, G_tilde)

    # F2G_tilde_bar
    F2G_tilde_bar = moy_fg_tilde(F2_tilde, G_tilde)

    # F1F2_tilde_bar
    F1F2_tilde_bar = moy_fg_tilde(F1_tilde, F2_tilde)

    # GAMMA_12_bar
    GAMMA_12_bar = GAMMA[0:kG, kG:(kG+kF1-1)]

    # GAMMA_13_bar
    GAMMA_13_bar = GAMMA[0:kG, (kG+kF1):(kG+kF1+kF2-1)]

    # GAMMA_23_bar
    GAMMA_23_bar = GAMMA[kG:(kG+kF1-1), (kG+kF1):(kG+kF1+kF2-1)]

    # Gamma_tilde
    Gamma_tilde = np.zeros((kG, kG, n))
    for i in range(n):
        Gamma_tilde[:, :, i] = (np.dot(EE, E3[:, :, i]) **
                                2)[0:kG, :] + GAMMA[0:kG, 0:kG]

    # Phi1_tilde
    Phi1_tilde = np.zeros((kF1, kF1, n))
    for i in range(n):
        Phi1_tilde[:, :, i] = (np.dot(EE, E3[:, :, i]) **
                            2)[kG:(kG+kF1), :] + GAMMA[kG:(kG+kF1), kG:(kG+kF1)]

    # Phi2_tilde
    Phi2_tilde = np.zeros((kF2, kF2, n))
    for i in range(n):
        Phi2_tilde[:, :, i] = (np.dot(EE, E3[:, :, i])**2)[(kG+kF1):(kG+kF1+kF2),
                            :] + GAMMA[(kG+kF1):(kG+kF1+kF2), (kG+kF1):(kG+kF1+kF2)]

    #
    # Gamma_tilde_bar
    Gamma_tilde_bar = np.mean(Gamma_tilde, axis=(0, 1))

    # Phi1_tilde_bar
    Phi1_tilde_bar = np.mean(Phi1_tilde, axis=(0, 1))

    # Phi2_tilde_bar
    Phi2_tilde_bar = np.mean(Phi2_tilde, axis=(0, 1))

    # Phi1Phi2_tilde_bar
    Phi1Phi2_tilde_bar = moy_fg_tilde(Phi1_tilde, Phi2_tilde)

    # T_T_prim_bar:
    T_T_prim_bar = moy_T_T_Prim(T, T)

    # T1_T1_prim_bar:
    T1_T1_prim_bar = moy_T_T_Prim(T1, T1)

    # T2_T2_prim_bar:
    T2_T2_prim_bar = moy_T_T_Prim(T2, T2)

    ###################################################################################################################
        ##               Fin def d'elements necessaires a la def des param a l'iteration [t+1]                           ##
        ###################################################################################################################

        ######################################################################################################################
        # A ACTUALISER SOUS FM3

    # Stock des valeurs des parametres a l'iteration it avant actualisation et l'obtention de leur valeur pour it+1
    # Objectif = nous permettre de calculer la difference de valeur d'une iteration a l'autre pour le critere d'arret
    # THETA[it] :
    A1_it = A1
    A2_it = A2
    B_it = B
    C1_it = C1
    C2_it = C2
    D_it = D  # New
    D1_it = D1  # New
    D2_it = D2  # New
    sigma2_X1_chap_it = sigma2_X1_chap
    sigma2_X2_chap_it = sigma2_X2_chap
    sigma2_Y_chap_it = sigma2_Y_chap

    ##############################################################
    # THETA[it+1,]
    # Parametres a l'iteration it+1 :
    B = np.transpose((np.transpose(G_tilde_Y_bar - np.matmul(Y_T_prim_bar, np.linalg.solve(T_T_prim_bar, G_tilde_T_bar)))) @
                    np.linalg.solve(Gamma_tilde_bar - np.matmul(G_tilde_T_prim_bar, np.linalg.solve(T_T_prim_bar, G_tilde_T_bar)), G_tilde_T_prim_bar))

    A1 = np.transpose((np.transpose(F1_tilde_X1_bar - np.matmul(X1_T1_prim_bar, np.linalg.solve(T1_T1_prim_bar, F1_tilde_T1_bar)))) @
                    np.linalg.solve(Phi1_tilde_bar - np.matmul(F1_tilde_T1_prim_bar, np.linalg.solve(T1_T1_prim_bar, F1_tilde_T1_bar)), F1_tilde_T1_prim_bar))

    A2 = np.transpose((np.transpose(F2_tilde_X2_bar - np.matmul(X2_T2_prim_bar, np.linalg.solve(T2_T2_prim_bar, F2_tilde_T2_bar)))) @
                    np.linalg.solve(Phi2_tilde_bar - np.matmul(F2_tilde_T2_prim_bar, np.linalg.solve(T2_T2_prim_bar, F2_tilde_T2_bar)), F2_tilde_T2_prim_bar))

    C1 = np.linalg.solve(Phi1Phi2_tilde_bar - (GAMMA_23_bar + F1F2_tilde_bar)**2, ((GAMMA_12_bar + F1G_tilde_bar)
                        * Phi2_tilde_bar) - ((GAMMA_13_bar + F2G_tilde_bar) * (GAMMA_23_bar + F1F2_tilde_bar)))
    C2 = np.linalg.solve(Phi1Phi2_tilde_bar - (GAMMA_23_bar + F1F2_tilde_bar)**2, ((GAMMA_13_bar + F2G_tilde_bar)
                        * Phi1_tilde_bar) - ((GAMMA_12_bar + F1G_tilde_bar) * (GAMMA_23_bar + F1F2_tilde_bar)))

    D = np.transpose((np.transpose(Y_T_prim_bar - np.matmul(np.transpose(B), G_tilde_T_prim_bar)))
                    @ np.linalg.solve(T_T_prim_bar, np.identity(T_T_prim_bar.shape[0])))
    D1 = np.transpose((np.transpose(X1_T1_prim_bar - np.matmul(np.transpose(A1), F1_tilde_T1_prim_bar)))
                    @ np.linalg.solve(T1_T1_prim_bar, np.identity(T1_T1_prim_bar.shape[0])))
    D2 = np.transpose((np.transpose(X2_T2_prim_bar - np.matmul(np.transpose(A2), F2_tilde_T2_prim_bar

    #

    

    # sigma2_Y_chap
    for i in range(n):
    dud1_Y[i, :]=Y[i, :]-np.dot(D.T, T[i, :])
    res1_Y=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_Y)
    res2_Y=np.array([np.sum(B**2)*Gamma_tilde])
    tab_res3_Y=np.zeros((n, 1, n))
    for i in range(n):
    tab_res3_Y[:, :, i]=np.dot(dud1_Y[i, :], B.T) * G_tilde[:, :, i]
    res3_Y=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_Y)
    res_Y_chap=res1_Y + res2_Y - 2*res3_Y
    sigma2_Y_chap=np.max((1/(n*qY))*np.sum(res_Y_chap))

    # sigma2_X1_chap
    for i in range(n):
    dud1_X1[i, :]=X1[i, :]-np.dot(D1.T, T1[i, :])
    res1_X1=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_X1)
    res2_X1=np.array([np.sum(A1**2)*Phi1_tilde])
    tab_res3_X1=np.zeros((n, 1, n))
    for i in range(n):
    tab_res3_X1[:, :, i]=np.dot(dud1_X1[i, :], A1.T) * F1_tilde[:, :, i]
    res3_X1=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_X1)
    res_X1_chap=res1_X1 + res2_X1 - 2*res3_X1
    sigma2_X1_chap=np.max((1/(n*qX1))*np.sum(res_X1_chap))

    # sigma2_X2_chap
    for i in range(n):
    dud1_X2[i, :]=X2[i, :]-np.dot(D2.T, T2[i, :])
    res1_X2=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_X2)
    res2_X2=np.array([np.sum(A2**2)*Phi2_tilde])
    tab_res3_X2=np.zeros((n, 1, n))
    for i in range(n):
    tab_res3_X2[:, :, i]=np.dot(dud1_X2[i, :], A2.T) * F2_tilde[:, :, i]
    res3_X2=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_X2)
    res_X2_chap=res1_X2 + res2_X2 - 2*res3_X2
    sigma2_X2_chap=np.max((1/(n*qX2))*np.sum(res_X2_chap))


    #





    # car a l'initialisation ceux sont des numeric et apres application de la boucle while il deviennent des
        # matrix. Si on ne le fait pas, l'application de la boucle lors de la deuxieme fois ne peut etre correcte.
        # Rq : elle n'est pas appliquee aux sigma2 car apres appli de la boucle while leur class n'est pas changee


    #

    # sigma2_Y_chap
    #######################################################
    for i in range(n):
        dud1_Y[i, :]=Y[i, :] - np.matmul(D.T, T[i, :])
    res1_Y=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_Y)
    res2_Y=np.array([np.sum(B**2)*Gamma_tilde])
    tab_res3_Y=np.zeros((n, 1, n))
    for i in range(n):
        tab_res3_Y[:, :, i]=np.matmul(
            np.matmul(dud1_Y[i, :], B.T), G_tilde[:, :, i])
    res3_Y=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_Y)
    res_Y_chap=res1_Y + res2_Y - 2*res3_Y
    sigma2_Y_chap=np.max((1/(n*qY))*np.sum(res_Y_chap))

    ####################################################
    # sigma2_X1_chap
    ####################################################
    for i in range(n):
        dud1_X1[i, :]=X1[i, :] - np.matmul(D1.T, T1[i, :])
    res1_X1=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_X1)
    res2_X1=np.array([np.sum(A1**2)*Phi1_tilde])
    tab_res3_X1=np.zeros((n, 1, n))
    for i in range(n):
        tab_res3_X1[:, :, i]=np.matmul(
            np.matmul(dud1_X1[i, :], A1.T), F1_tilde[:, :, i])
    res3_X1=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_X1)
    res_X1_chap=res1_X1 + res2_X1 - 2*res3_X1
    sigma2_X1_chap=np.max((1/(n*qX1))*np.sum(res_X1_chap))

    ####################################################
    # sigma2_X2_chap
    ####################################################
    for i in range(n):
        dud1_X2[i, :]=X2[i, :] - np.matmul(D2.T, T2[i, :])
    res1_X2=np.apply_along_axis(lambda x: np.sum(x**2), 1, dud1_X2)
    res2_X2=np.array([np.sum(A2**2)*Phi2_tilde])
    tab_res3_X2=np.zeros((n, 1, n))
    for i in range(n):
        tab_res3_X2[:, :, i]=np.matmul(
            np.matmul(dud1_X2[i, :], A2.T), F2_tilde[:, :, i])
    res3_X2=np.apply_along_axis(lambda x: np.mean(x), (1, 2), tab_res3_X2)
    res_X2_chap=res1_X2 + res2_X2 - 2*res3_X2
    sigma2_X2_chap=np.max((1/(n*qX2))*np.sum(res_X2_chap))

    ########################
    # Psi_X1, Psi_X2 et Psi_Y a it+1
    ########################
    Psi_Y=sigma2_Y_chap*np.eye(qY)
    Psi_X1=sigma2_X1_chap*np.eye(qX1)
    Psi_X2=sigma2_X2_chap*np.eye(qX2)

    #

    ##############################
    # ---- Conversion des parametres de matrix a numeric----
    # On convertit C1 et C2 en numeric car apres estimation ce sont des matrix et le debut du code est cree avec des C1 et C2 numeric.

    C1=C1.flatten().tolist()
    C2=C2.flatten().tolist()


    # car a l'initialisation ceux sont des numeric et apres application de la boucle while il deviennent des
        # matrix. Si on ne le fait pas, l'application de la boucle lors de la deuxieme fois ne peut etre correcte.
        # Rq : elle n'est pas appliquee aux sigma2 car apres appli de la boucle while leur class n'est pas changee

    #

    # mesure du changement d'itération :
    diff=sum([
    sum(abs(D - D_it)/abs(D)),
    sum(abs(D1 - D1_it)/abs(D1)),
    sum(abs(D2 - D2_it)/abs(D2)),
    sum(abs(B - B_it)/abs(B)),
    sum(abs(A1 - A1_it)/abs(A1)),
    sum(abs(A2 - A2_it)/abs(A2)),
    abs(C1 - C1_it)/abs(C1),
    abs(C2 - C2_it)/abs(C2),
    abs(sigma2_Y_chap - sigma2_Y_chap_it)/abs(sigma2_Y_chap),
    abs(sigma2_X1_chap - sigma2_X1_chap_it)/abs(sigma2_X1_chap),
    abs(sigma2_X2_chap - sigma2_X2_chap_it)/abs(sigma2_X2_chap)
    ])

    diffgraph[it+1]=diff

    #


    print('iteration', it, '\n', '\n',
        'difference', diffgraph[it],
        '\n', 'D_chap', D,
        '\n', 'D1_chap', D1,
        '\n', 'D2_chap', D2,
        '\n', 'B_chap', B,
        '\n', 'A1_chap', A1, '\n', 'A2_chap', A2,
        '\n', 'C1_chap', C1, '\n', 'C2_chap', C2,
        '\n', 'sigma2_Y_chap', sigma2_Y_chap,
        '\n', 'sigma2_X1_chap', sigma2_X1_chap,
        '\n', 'sigma2_X2_chap', sigma2_X2_chap,  '\n')

# fin de boucle du gros while

#

return {
    "Factors": np.column_stack((G_tilde, F1_tilde, F2_tilde)),
    "C": [C1, C2],
    "B": B,
    "A1": A1,
    "A2": A2,
    "D": D,
    "D1": D1,
    "D2": D2,
    "sigma2": [sigma2_Y_chap, sigma2_X1_chap, sigma2_X2_chap],
    "Diff": diff,
    "Diff_it": diffgraph,
    "Conv_it": it
}

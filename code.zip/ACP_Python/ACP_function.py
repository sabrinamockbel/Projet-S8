
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import numpy as np
import matplotlib.pyplot as plt






def ACP(observables):

    scaler = StandardScaler()
    scaled_df = scaler.fit_transform(observables)

    pca = PCA()
    pca.fit(scaled_df)

    loadings = pca.components_.T * np.sqrt(pca.explained_variance_)

    # Get the percentage of variance explained by each principal component
    variance_explained = pca.explained_variance_ratio_

    plt.xlabel('PC1 ({}%)'.format(round(variance_explained[0]*100, 2)))
    plt.ylabel('PC2 ({}%)'.format(round(variance_explained[1]*100, 2)))

    max_norm = np.max(np.abs(np.concatenate([pca.components_[0,:], pca.components_[1,:]])))

    for i, (x, y) in enumerate(zip(pca.components_[0,:], pca.components_[1,:])):
        plt.arrow(0, 0, x/max_norm, y/max_norm, color='k', alpha=0.5)
        plt.text((x/max_norm) * 1.2, (y/max_norm) * 1.2, observables.columns[i], color='k', ha='center', va='center')

    # Add a circle of radius one
    circle = plt.Circle((0, 0), 1, color='r', fill=False)
    plt.gca().add_artist(circle)

    #X and y have the same scale
    plt.gca().set_aspect('equal', adjustable='box')

    #limite de x et y 
    plt.xlim(-1.15, 1.15)
    plt.ylim(-1.15, 1.15)

    plt.show()